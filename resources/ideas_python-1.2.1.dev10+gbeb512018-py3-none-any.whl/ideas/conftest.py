import pytest


@pytest.fixture(autouse=True)
def set_cwd_to_tmp_path(monkeypatch, tmp_path):
    """Change the cwd to a tmp path. Used for generating doctest examples"""
    monkeypatch.chdir(tmp_path)
