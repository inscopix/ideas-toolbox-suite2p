"""Module with framework for generating output data in IDEAS tools"""

import json
import logging
import shutil
import warnings
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, TypeVar, Union

from ideas import constants, exceptions

logger = logging.getLogger()

# On most Linux max filename len is 255 bytes, leave some buffer for prefix, suffix, and ext
MAX_FILENAME_LEN = 200


def input_paths_to_output_prefix(
    *input_paths: List[List[str | Path | None] | str | Path | None],
    max_name_len: int | None = None,
    max_prefix_len: int = MAX_FILENAME_LEN,
    sep="_",
):
    """
    Generate an output prefix from a set of input paths

    Examples:

        >>> input_paths_to_output_prefix('aaaaa', 'bbbbb', max_name_len=2, max_prefix_len=6)
        'aa_bb_'

        >>> input_paths_to_output_prefix('aaaaa', 'bbbbb', max_name_len=None, max_prefix_len=6)
        'aaaaa_'

    :param input_paths: Set of input paths, can be list of strings, paths, or lists of strings or paths
    :param max_name_len: Maximum number of characters to use from each input path
        If None, no max limit on each input path, but some paths may be cutoff from the output
        if the final length of the joined names is greater than `max_prefix_len`
    :param max_prefix_len: Maximum number of characters in the final output prefix.
    :param sep: Separator to use between input paths
    """
    output_prefix = ""
    for _input_paths in input_paths:
        if not isinstance(_input_paths, list):
            _input_paths = [_input_paths]

        for _input_path in _input_paths:
            if _input_path is None:
                continue
            if isinstance(_input_path, str):
                _input_path = Path(_input_path)
            input_name = _input_path.stem.replace(" ", sep)

            if output_prefix:
                output_prefix += "_"

            if max_name_len:
                output_prefix += input_name[0 : min(len(input_name), max_name_len)]
            else:
                output_prefix += input_name

    if len(output_prefix) > (max_prefix_len - 1):
        output_prefix = output_prefix[0 : (max_prefix_len - 1)]
    output_prefix += sep

    return output_prefix


def _load_and_remove_output_metadata():
    """[internal] Load and remove v2 output metadata to register"""
    path = Path("output_metadata.json")
    with open(path, "r") as f:
        metadata = json.load(f)
    path.unlink()
    return metadata


def _resolve_output_file_path(
    output_file: Path,
    output_dir: Path,
    subdir: Optional[str] = None,
    name: Optional[str] = None,
    prefix: Optional[str] = None,
    suffix: Optional[str] = None,
    copy: bool = True,
):
    """Helper function for resolving output file paths relative to an output directory"""
    # See if output file exists
    if not output_file.exists():
        # See if output file exists relative to output dir
        if output_file.is_absolute():
            raise exceptions.OutputDataFileDoesNotExist(
                f"Failed to find output file while writing output data: {output_file}"
            )

        # check if relative file exists in output dir
        if (output_dir / output_file).exists():
            output_file = output_dir / output_file
        else:
            # check if relative file exists in subdir
            if subdir and (output_dir / subdir / output_file).exists():
                output_file = output_dir / subdir / output_file
            else:
                raise exceptions.OutputDataFileDoesNotExist(
                    f"Failed to find output file while writing output data: {output_file}"
                )

    if output_file.is_dir():
        raise exceptions.OutputDataException(
            f"Output file cannot be a directory: {output_file}"
        )

    original_output_dir = output_dir
    if subdir:  # append subdir if specified
        output_dir = output_dir / subdir

    # if the output dir exists, but is a file, then cannot resolve path
    if output_dir.exists() and output_dir.is_file():
        raise exceptions.OutputDataException(
            f"Cannot create directory for resolved file path due to existing file with the same name: {output_dir}. Provide a different subdir, or delete the existing file."
        )

    output_dir.mkdir(exist_ok=True)

    # copy/rename output file as necessary
    # track the original file name in case copied files
    # need to be cleaned up post-registration
    output_file = output_file.resolve()
    resolved_output_file, original_output_file = Path(output_file), Path(output_file)
    if output_dir not in output_file.parents:
        resolved_output_file = output_dir / output_file.name
    if name:
        resolved_output_file = output_dir / name
    if prefix:
        resolved_output_file = output_dir / (prefix + resolved_output_file.name)
    if suffix:
        resolved_output_file = output_dir / (
            resolved_output_file.stem + suffix + resolved_output_file.suffix
        )

    if resolved_output_file != output_file:
        if copy:
            shutil.copy2(output_file, resolved_output_file)
            output_file = resolved_output_file
        else:
            output_file = output_file.rename(resolved_output_file)
            # since output file is being renamed, no original file to return
            original_output_file = None
    else:
        # output file remains unchanged, no original file to return
        original_output_file = None

    return output_file.relative_to(original_output_dir), original_output_file


"""Tag is a categorical label that describes an output file."""
Tag = TypeVar("Tag", bound=str)


@dataclass
class Metadata:
    """
    Piece of key, value data that describes an output file.

    :param key: Unique identifier for the metadata across output files
    :type key: str
    :param name: Friendly name for the metadata to display in IDEAS
    :type name: str
    :param value: The value of the metadata
    :type value: Union[str, bool, int, float, List[str]]
    """

    key: str
    name: str
    value: Union[str, bool, int, float, List[str]]

    def to_dict(self):
        """Serialize to dict to save in output data file"""
        return {"key": self.key, "name": self.name, "value": self.value}

    @classmethod
    def from_dict(cls, instance):
        """Deserialize from dict in output data file"""
        return cls(key=instance["key"], name=instance["name"], value=instance["value"])


@dataclass
class Preview:
    """
    A file which describes an output file.
    Preview files can be figures (i.e., images), movies (i.e., videos), json, or even an html webpage (static assets only).
    Previews are meant to be small in size, giving a brief glance, or impression at the results store in particular output file.

    :param file_path: The path to the preview file
    :type file_path: Path
    :param caption: A short description of the preview.
    :type caption: str
    :param original_file_path: The original path of the file prior to
        renaming and/or moving based on subdirs, prefixes, and suffixes.
        Used to clean up files after renaming/moving to new paths in the output dir.
        If None, no file to clean up.
    :type original_file_path: Path | None
    """

    file_path: Path
    caption: str
    original_file_path: Path | None = None

    def to_dict(self):
        """Serialize to dict to save in output data file"""
        return {"file": str(self.file_path), "caption": self.caption}

    @classmethod
    def from_dict(cls, instance):
        """Deserialize from dict in output data file"""
        return cls(file_path=Path(instance["file"]), caption=instance["caption"])


@dataclass
class OutputFile:
    """
    Results generated by a tool, saved to a file, and saved in IDEAS.

    :param file_path: The path to the output file
    :type file_path: Path
    :param output_dir: Output directory where output files are generated.
    :type output_dir: Path
    :param subdir: A subdirectory in the output directory where output files should be moved.
    Helpful for organizing result files into subdirectories for output columns
    :type subdir: Optional[str | Path]
    :param prefix: Prefix to optionally prepend to the output filename, and associated preview filenames.
    :type prefix: Optional[str]
    :param prefix: Suffix to optionally append to the output filename, and associated preview filenames.
    :type prefix: Optional[str]
    :param previews: List of previews to show in IDEAS for the output file
    :type previews: List[Preview]
    :param metadata: List of metadata to show in IDEAS for the output file
    :type metadata: List[Metadata]
    :param tags: List of tags to show in IDEAS for the output file
    :type tags: List[Tag]
    :param raise_missing_file: Raise an error if an output file is missing, otherwise a runtime warning is raised.
    :type raise_missing_file: bool
    :param original_file_path: The original path of the file prior to
        renaming and/or moving based on subdirs, prefixes, and suffixes.
        Used to clean up files after renaming/moving to new paths in the output dir.
        If None, no file to clean up.
    :type original_file_path: Path | None
    """

    file_path: Path
    output_dir: Path
    subdir: Optional[str | Path] = None
    prefix: Optional[str] = None
    suffix: Optional[str] = None
    previews: List[Preview] = field(default_factory=list)
    metadata: List[Metadata] = field(default_factory=list)
    tags: List[Tag] = field(default_factory=list)
    raise_missing_file: bool = True
    original_file_path: Path | None = None

    def to_dict(self):
        """Serialize to dict to save in output data file"""
        return {
            "file": str(self.file_path),
            "previews": [p.to_dict() for p in self.previews],
            "metadata": [m.to_dict() for m in self.metadata],
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, instance: Dict, output_dir: str | Path):
        """Deserialize from dict in output data file"""
        return cls(
            file_path=Path(instance["file"]),
            previews=[Preview.from_dict(p) for p in instance["previews"]],
            metadata=[Metadata.from_dict(m) for m in instance["metadata"]],
            tags=[Tag(t) for t in instance["tags"]],
            output_dir=output_dir,
        )

    def register_preview(
        self,
        file_path: str | Path,
        caption: str = "",
        output_dir: Optional[str | Path] = None,
        subdir: Optional[str | Path] = None,
        name: Optional[str] = None,
        prefix: Optional[str] = None,
        suffix: Optional[str] = None,
        copy: bool = True,
    ):
        """
        Register a preview with the output file

        :param file_path: The path to the preview file
        :type file_path: str | Path
        :param caption: A short description of the preview.
        :type caption: str
        :param output_dir: Output directory where output files are generated.
        If not specified, default to output directory for output data.
        :type output_dir: Optional[str | Path]
        :param subdir: A subdirectory in the output directory where output files should be moved.
        Helpful for organizing result files into subdirectories for output columns
        :type subdir: Optional[str | Path]
        :param prefix: Prefix to optionally prepend to the output filename, and associated preview filenames.
        :type prefix: Optional[str]
        :param prefix: Suffix to optionally append to the output filename, and associated preview filenames.
        :type prefix: Optional[str]

        :return: The output file (for command chaining)
        :rtype: OutputFile
        :raises OutputDataFileDoesNotExist: If the preview file does not exist.
        """
        if output_dir is None:
            output_dir = self.output_dir

        if not isinstance(output_dir, Path):
            output_dir = Path(output_dir)

        if subdir is None:
            subdir = self.subdir
        if prefix is None:
            prefix = self.prefix
        if suffix is None:
            suffix = self.suffix

        if not isinstance(file_path, Path):
            file_path = Path(file_path)

        # check if this preview file has already been registered to output data
        preview_file = None
        try:
            resolved_file_path, original_file_path = _resolve_output_file_path(
                file_path,
                output_dir,
                subdir=subdir,
                name=name,
                prefix=prefix,
                suffix=suffix,
                copy=copy,
            )
        except exceptions.OutputDataFileDoesNotExist as error:
            if self.raise_missing_file:
                raise error
            else:
                logger.warning(str(error))
                warnings.warn(str(error), RuntimeWarning)
                return self

        for _preview_file in self.previews:
            if resolved_file_path == _preview_file.file_path:
                preview_file = _preview_file

        if not preview_file:
            self.previews.append(
                Preview(
                    file_path=resolved_file_path,
                    original_file_path=original_file_path,
                    caption=caption,
                )
            )
        else:
            preview_file.caption = caption
        return self

    def register_metadata(self, key: str, value: str, name: Optional[str] = None):
        """
        Register metadata with the output file

        :param key: Unique identifier for the metadata across output files
        :type key: str
        :param name: Friendly name for the metadata to display in IDEAS
        :type name: str
        :param value: The value of the metadata
        :type value: Union[str, bool, int, float, List[str]]

        :return: The output file (for command chaining)
        :rtype: OutputFile
        """
        if not name:
            # give a pretty name for metadata key
            name = key.replace("-", " ").replace("_", " ").title()

        self.metadata.append(Metadata(key=key, name=name, value=value))
        return self

    def register_metadata_dict(
        self, **kwargs: Dict[str, Union[str, bool, int, float, List[str]]]
    ):
        """
        Register metadata dictionary with the output file

        :param kwargs: Dictionary with key-value pairs of metadata
        :type kwargs: str
        :param value: The value of the metadata
        :type value: Dict[str, Union[str, bool, int, float, List[str]]]

        :return: The output file (for command chaining)
        :rtype: OutputFile
        """
        for key, value in kwargs.items():
            self.register_metadata(key=key, value=value)
        return self

    def register_tags(self, *tags: List[str]):
        """
        Register tags with the output file

        :param tags: Tags to register
        :type tags: List[str]

        :return: The output file (for command chaining)
        :rtype: OutputFile
        """
        for tag in tags:
            self.tags.append(tag)
        return self


class OutputData:
    """
    Collection of output files generated by an IDEAS tool.
    Each output file has associated previews, metadata, and tags to display in IDEAS.

    :param output_files: List of output files registered by a tool.
    :type output_files: List[OutputFile]
    :param output_dir: Output directory where output files are generated.
    :type output_dir: Path
    :param append: Flag indicating whether to append new output files
    to existing output data already registered by the tool.
    :param raise_missing_file: Raise an error if an output file is missing, otherwise a runtime warning is raised.
    :type raise_missing_file: bool
    :param keep_original_files: Flag indicating whether to keep files
        post-registration that have been copied to a new location in the output dir
        based on subdirs, prefixes, and suffixes provided during registration.
    :type keep_original_files: bool
    """

    output_files: List[OutputFile]
    output_dir: Path
    append: bool
    raise_missing_file: bool
    keep_original_files: bool

    def __init__(
        self,
        output_dir: Optional[str | Path] = None,
        append: bool = True,
        raise_missing_file: bool = False,
        keep_original_files: bool = False,
    ):
        """Initialize output data

        :param output_dir: Output directory where output files are generated.
        If None, then the current working directory is used.
        :type output_dir: Optional[str | Path]
        :param append: Flag indicating whether to append new output files
        to existing output data already registered by the tool.
        :param raise_missing_file: Raise an error if an output file is missing, otherwise a runtime warning is raised.
        :type raise_missing_file: bool
        """
        if not output_dir:
            output_dir = Path.cwd()
        if not isinstance(output_dir, Path):
            output_dir = Path(output_dir)
        self.output_dir = output_dir

        self.file_pathname = output_dir / constants.OUTPUT_DATA_JSON_FILENAME
        self.output_files = []
        self.append = append
        self.raise_missing_file = raise_missing_file
        self.keep_original_files = keep_original_files

    def open(self):
        """Open output data for writing."""
        if self.append and self.file_pathname.exists():
            with open(self.file_pathname, "r") as file:
                output_data = json.load(file)
                # todo: validate schema here
                for output_file in output_data["output_files"]:
                    self.output_files.append(
                        OutputFile.from_dict(output_file, self.output_dir)
                    )

    def close(self):
        """Close output data for writing."""
        output_data = {
            "schema_version": constants.OUTPUT_DATA_SCHEMA_VERSION,
            "output_files": [f.to_dict() for f in self.output_files],
        }
        with open(self.file_pathname, "w") as file:
            json.dump(output_data, file, indent=4)

        if not self.keep_original_files:
            # Clean up any files copied to different locations in the output dir
            # according to subdirs, prefixes and suffixes.
            # Track the original file paths registered, and the final registered files paths
            original_files, registered_files = set(), set()
            for output_file in self.output_files:
                if output_file.original_file_path:
                    original_files.add(output_file.original_file_path)
                registered_files.add(self.output_dir / output_file.file_path)

                for preview in output_file.previews:
                    if preview.original_file_path:
                        original_files.add(preview.original_file_path)
                    registered_files.add(self.output_dir / preview.file_path)

            # Remove any original files that were copied, but also registered with the original location
            original_files = original_files.difference(registered_files)
            for original_file in original_files:
                try:
                    original_file.unlink()
                except FileNotFoundError:
                    logger.warning(
                        "Failed to find renamed file to clean up post-registration."
                    )
                    warnings.warn(
                        "Failed to find renamed file to clean up post-registration.",
                        RuntimeWarning,
                    )

    def __enter__(self):
        """Enter for context manager."""
        self.open()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """Exit for context manager."""
        self.close()

    def register_file(
        self,
        file_path: str | Path,
        previews: Optional[List[Preview]] = None,
        metadata: Optional[List[Metadata]] = None,
        tags: Optional[List[Tag]] = None,
        output_dir: Optional[str | Path] = None,
        subdir: Optional[str | Path] = None,
        name: Optional[str] = None,
        prefix: Optional[str] = None,
        suffix: Optional[str] = None,
        copy: bool = True,
    ):
        """
        Register an output file as output data.

        :param file_path: The path to the output file
        :type file_path: str | Path
        :param output_dir: Output directory where output files are generated.
        :type output_dir: Path
        :param previews: List of previews to show in IDEAS for the output file
        :type previews: Optional[List[Preview]]
        :param metadata: List of metadata to show in IDEAS for the output file
        :type metadata: Optional[List[Metadata]]
        :param tags: List of tags to show in IDEAS for the output file
        :type tags: Optional[List[Tag]]
        :param output_dir: Output directory where output files are generated.
        If not specified, default to current working directory.
        :type output_dir: Optional[str | Path]
        :param subdir: A subdirectory in the output directory where output files should be moved.
        Helpful for organizing result files into subdirectories for output columns
        :type subdir: Optional[str | Path]
        :param prefix: Prefix to optionally prepend to the output filename, and associated preview filenames.
        :type prefix: Optional[str]
        :param prefix: Suffix to optionally append to the output filename, and associated preview filenames.
        :type prefix: Optional[str]

        :return: The output file (for command chaining)
        :rtype: OutputFile
        :raises OutputDataFileDoesNotExist: If an output file does not exist.
        """
        if output_dir is None:
            output_dir = self.output_dir
        if not isinstance(output_dir, Path):
            output_dir = Path(output_dir)

        if not isinstance(file_path, Path):
            file_path = Path(file_path)

        # check if this output file has already been registered to output data
        output_file = None
        try:
            resolved_file_path, original_file_path = _resolve_output_file_path(
                file_path,
                output_dir,
                subdir=subdir,
                name=name,
                prefix=prefix,
                suffix=suffix,
                copy=copy,
            )
        except exceptions.OutputDataFileDoesNotExist as error:
            if self.raise_missing_file:
                raise error
            else:
                logger.warning(str(error))
                warnings.warn(str(error), RuntimeWarning)
                return output_file

        for _output_file in self.output_files:
            if resolved_file_path == _output_file.file_path:
                output_file = _output_file

        if not output_file:
            output_file = OutputFile(
                file_path=resolved_file_path,
                original_file_path=original_file_path,
                previews=previews if previews else [],
                metadata=metadata if metadata else [],
                tags=tags if tags else [],
                output_dir=self.output_dir,
                subdir=subdir,
                prefix=prefix,
                suffix=suffix,
                raise_missing_file=self.raise_missing_file,
            )
            self.output_files.append(output_file)
        return output_file


@contextmanager
def register(
    output_dir: Optional[str | Path] = None,
    append: bool = True,
    raise_missing_file: bool = False,
    keep_original_files: bool = False,
):
    """
    Opens a context manager to register output data for an IDEAS tool.

    Examples:

        >>> input_paths = ["input1.csv", "input2.csv"]

        >>> from pathlib import Path
        >>> for f in ["summary.txt", "results.csv", "figure.svg", "movie.mp4"]:
        ...     Path(f).touch()

        >>> from ideas.tools import outputs
        >>> prefix = outputs.input_paths_to_output_prefix(input_paths)

        >>> with outputs.register() as output_data:
        ...     output_file = output_data.register_file(
        ...         "summary.txt",
        ...     ).register_preview(
        ...         "figure.svg",
        ...         caption="A special figure visualizing summary of the analysis!"
        ...     ).register_metadata_dict(
        ...         key1="cool",
        ...         key2="beans"
        ...     )
        ...     output_file = output_data.register_file(
        ...         "results.csv",
        ...         subdir="results",
        ...         prefix=prefix
        ...     ).register_preview(
        ...         "figure.svg",
        ...         caption="A preview figure of the results!"
        ...     ).register_preview(
        ...         "movie.mp4",
        ...         caption="A preview movie of the results!"
        ...     ).register_metadata_dict(
        ...         **{"key1" : True, "key2" : 42}
        ...     )

        >>> # List files in output dir post-registration
        >>> import os
        >>> sorted([str(f.relative_to(Path.cwd())) for f in Path.cwd().rglob("*") if f.is_file()])
        ['figure.svg', 'output_data.json', 'results/input1_input2_figure.svg', 'results/input1_input2_movie.mp4', 'results/input1_input2_results.csv', 'summary.txt']

    :param output_dir: Output directory where output files are generated.
    If None, then the current working directory is used.
    :type output_dir: Optional[str | Path]
    :param append: Flag indicating whether to append new output files
    to existing output data already registered by the tool.
    :param raise_missing_file: Raise an error if an output file is missing, otherwise a runtime warning is raised.
    :type raise_missing_file: bool
    :param keep_original_files: Flag indicating whether to keep files
        post-registration that have been copied to a new location in the output dir
        based on subdirs, prefixes, and suffixes provided during registration.
    :type keep_original_files: bool

    :raises OutputDataFileDoesNotExist: If an output file does not exist and `raise_missing_file` is True.
    """
    with OutputData(
        output_dir,
        append=append,
        raise_missing_file=raise_missing_file,
        keep_original_files=keep_original_files,
    ) as output_data:
        try:
            yield output_data
        finally:
            pass
