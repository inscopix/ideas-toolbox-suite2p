; Bash tree-sitter queries
; --------------
;

(program
  (command
    (command_name
      (word) @func.name
    )
    [
      (simple_expansion
        (variable_name) @arg.name
      )
      (expansion
        (variable_name) @arg.name
      )
    ]
  )
)
