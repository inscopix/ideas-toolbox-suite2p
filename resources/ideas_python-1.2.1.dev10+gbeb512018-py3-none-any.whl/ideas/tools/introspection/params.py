import glob
import os
import pathlib
import typing
from abc import ABC, abstractmethod

from click.types import BoolParamType

from ideas import exceptions

# Compatibility check for python 3.10# Compatibility check for python 3.10
try:
    from enum import StrEnum
except ImportError:
    from backports.strenum import StrEnum


T = typing.TypeVar("T")


class IdeasParameterType(StrEnum):
    """
    The types of parameters supported in IDEAS
    Each parameter type determines different behavior
    for the corresponding analysis table columns in IDEAS.
    """

    PATH = "ToolPathParam"  # File path parameter
    INT = "ToolIntRangeParam"  # Int parameter with optional range
    FLOAT = "ToolFloatRangeParam"  # Float parameter with optional range
    BOOL = "ToolBooleanParam"  # Bool parameter
    STR = "ToolStringParam"  # String parameter


class Parameter(ABC, typing.Generic[T]):
    """
    Abstract class to represent a parameter introspected from a function signature.

    :param key: The name of the parameter in the function signature.
    :param type_annotation: The type annotation specified for the
        parameter in the function signature.
    :param default: The default value assigned to the parameter
        in the function signature.
    :param ideas_type: The corresponding parameter type in IDEAS.
    :param validation_class: The python type class to use for validating
        input instances of the parameter.
    :param required: Indicates if the parameter is required (i.e., optional or not)
    """

    def __init__(
        self, key: str, type_annotation: str, default: typing.Any, required: bool = True
    ):
        self.key = key
        self.type_annotation = type_annotation
        self.default = default
        self.required = required

    def __eq__(self, other):
        return (
            self.key == other.key
            and self.type_annotation == other.type_annotation
            and self.default == other.default
            and self.to_dict() == other.to_dict()
            and self.required == other.required
        )

    def __repr__(self):
        return f"Parameter(key={self.key}, type_annotation={self.type_annotation}, default={self.default}, optional={self.required})"

    @property
    @abstractmethod
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        pass

    @property
    @abstractmethod
    def data_type(self) -> str:
        pass

    @property
    @abstractmethod
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        pass

    def to_dict(self) -> dict:
        """Convert to dict for IDEAS tool spec."""
        data = {"param_type": str(self.ideas_type)}
        if self.default is not None and isinstance(self.default, self.validation_class):
            data["default"] = self.default
        return data

    def validate(self, instance: typing.Any) -> None:
        """
        Validate an input value for this parameter.

        :raises ToolInputsFormatError: If the input value failed to validate for this parameter.
        """
        if instance is None:
            if self.required:
                # If this param is not optional, raise an error
                raise exceptions.ToolInputsFormatError(
                    f"Type annotation for parameter {self.key} is not optional, but input value `None` was provided. Use `| None` in the type annotation for this parameter.",
                    key=self.key,
                    value=instance,
                )
            else:
                # Otherwise, skip validation of instance with data class
                return

        if not isinstance(instance, self.validation_class):
            raise exceptions.ToolInputsFormatError(
                f"Input value ({instance}) for parameter {self.key} does not match expected json type {self.validation_class.__name__}",
                key=self.key,
                value=instance,
            )

    def coerce_value(self, value: str) -> T:
        """
        Coerce string representations of parameters to their native type. Used for CLI-defined
        arguments that define tool parameters.
        """
        try:
            return self.validation_class(value)
        except ValueError:
            raise exceptions.ToolInputsFormatError(
                f"Input value ({value}) for parameter {self.key} does not match expected type {self.validation_class}",
                key=self.key,
                value=value,
            )


class PathParameter(Parameter[str]):
    """
    Parameter for an input file.
    This parameter type only supports a single input file.
    See `PathMultipleParameter` for multiple file support.
    """

    def __init__(self, key: str, type_annotation: str, default: typing.Any):
        super().__init__(
            key=key,
            type_annotation=type_annotation,
            default=default,
        )

    @property
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        return IdeasParameterType.PATH

    @property
    def data_type(self) -> str:
        return "string"

    @property
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        return str

    def to_dict(self) -> dict:
        """Convert to dict for IDEAS tool spec."""
        data = super().to_dict()
        data["multiple"] = False
        if "default" in data:
            del data["default"]
        return data

    def validate(self, instance: typing.Any):
        """
        Validate an input value for this parameter.

        :raises ToolInputsFormatError: If the input value failed to validate for this parameter.
        """
        super().validate(instance)

        if instance is None:
            return

        if not os.path.exists(os.path.expanduser(instance)):
            # if the type is a path param and the file doesn't exist, hard fail
            raise exceptions.ToolInputsFileNotFoundError(
                f"Failed to find file for path param: {os.path.expanduser(instance)}",
                file=instance,
            )


class PathOptionalParameter(PathParameter):
    """
    Parameter for an optional input file.
    This parameter type only supports a single input file.
    See `PathMultipleParameter` for multiple file support.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = False


class PathMultipleParameter(Parameter[list]):
    """Parameter for one or more input files."""

    def __init__(self, key: str, type_annotation: str, default: typing.Any):
        super().__init__(
            key=key,
            type_annotation=type_annotation,
            default=default,
        )

    @property
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        return IdeasParameterType.PATH

    @property
    def data_type(self) -> str:
        return "array"

    @property
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        return list

    def to_dict(self) -> dict:
        """Convert to dict for IDEAS tool spec."""
        data = super().to_dict()
        data["multiple"] = True
        if "default" in data:
            del data["default"]
        return data

    def validate(self, instance: typing.Any):
        """
        Validate an input value for this parameter.

        :raises ToolInputsFormatError: If the input value failed to validate for this parameter.
        """
        super().validate(instance)

        if instance is None:
            return

        if not isinstance(instance, list) or not all(
            [isinstance(v, str) for v in instance]
        ):
            raise exceptions.ToolInputsFormatError(
                f"Input value ({instance}) for parameter {self.key} does not match expected json type list with all string values",
                key=self.key,
                value=instance,
            )

        for v in instance:
            if not os.path.exists(os.path.expanduser(v)):
                # if the type is a path param and the file doesn't exist, hard fail
                raise exceptions.ToolInputsFileNotFoundError(
                    f"Failed to find file for path param: {os.path.expanduser(v)}",
                    file=v,
                )

    def coerce_value(self, value: str) -> list:
        """
        Supports specifying a list of files (which may be a list of one), supporting:
            - glob patterns: /tmp/foo*.isxd
            - csv list: /tmp/foo_part1.isxd,/tmp/foo_part2.isxd
        """
        paths = []
        for part in value.split(","):
            path = str(pathlib.Path(part).expanduser())
            paths.extend(p for p in glob.glob(path))


class PathMultipleOptionalParameter(PathMultipleParameter):
    """Parameter for one or more optional input files."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = False


class IntParameter(Parameter[int]):
    """Parameter for integer inputs."""

    def __init__(self, key: str, type_annotation: str, default: typing.Any):
        super().__init__(
            key=key,
            type_annotation=type_annotation,
            default=default,
        )

    @property
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        return IdeasParameterType.INT

    @property
    def data_type(self) -> str:
        return "integer"

    @property
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        return int


class IntOptionalParameter(IntParameter):
    """Parameter for optional integer inputs"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = False


class FloatParameter(Parameter[float]):
    """Parameter for floating point inputs."""

    def __init__(self, key: str, type_annotation: str, default: typing.Any):
        super().__init__(
            key=key,
            type_annotation=type_annotation,
            default=default,
        )

    @property
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        return IdeasParameterType.FLOAT

    @property
    def data_type(self) -> str:
        return "float"

    @property
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        return float

    def validate(self, instance: typing.Any) -> None:
        """
        Validate an input value for this parameter.

        :raises ToolInputsFormatError: If the input value failed to validate for this parameter.
        """
        try:
            super().validate(instance)
        except exceptions.ToolInputsFormatError as error:
            if not isinstance(instance, int):
                raise error


class FloatOptionalParameter(FloatParameter):
    """Parameter for optional float inputs"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = False


class BoolParameter(Parameter[bool]):
    """Parameter for boolean inputs."""

    def __init__(self, key: str, type_annotation: str, default: typing.Any):
        super().__init__(
            key=key,
            type_annotation=type_annotation,
            default=default,
        )

    @property
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        return IdeasParameterType.BOOL

    @property
    def data_type(self) -> str:
        return "boolean"

    @property
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        return bool

    def coerce_value(self, value: str) -> bool:
        """
        Supports boolean-ish strings like:
            "1" "true" "t" "yes" "y" "on"
            "0" "false" "f" "no" "n" "off"
        """
        return BoolParamType().convert(value, param=None, ctx=None)


class BoolOptionalParameter(BoolParameter):
    """Parameter for optional boolean inputs"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = False


class StringParameter(Parameter[str]):
    """Parameter for string inputs."""

    def __init__(self, key: str, type_annotation: str, default: typing.Any):
        super().__init__(
            key=key,
            type_annotation=type_annotation,
            default=default,
        )

    @property
    def ideas_type(self) -> IdeasParameterType:
        """The corresponding type of parameter type in IDEAS"""
        return IdeasParameterType.STR

    @property
    def data_type(self) -> str:
        return "string"

    @property
    def validation_class(self) -> type:
        """The python type class to use for validating input instances of the parameter."""
        return str

    def validate(self, instance: typing.Any) -> None:
        """
        Validate an input value for this parameter.

        :raises ToolInputsFormatError: If the input value failed to validate for this parameter.
        """
        try:
            super().validate(instance)
        except exceptions.ToolInputsFormatError as e:
            # If the instance is None, then an error is thrown because this parameter is not optional
            if instance is None:
                raise e

            # If the type annotation is str, then raise validation error. Otherwise dismiss since this param type is default.
            if self.type_annotation == "str":
                raise exceptions.ToolInputsFormatError(
                    f"Input value ({instance}) for parameter {self.key} does not match expected type {self.validation_class}."
                    f"\nIf this parameter is meant to be a file input, ensure you use the type annotation `pathlib.Path` or `List\\[pathlib.Path]` in your function.",
                    key=self.key,
                    value=instance,
                )


class StringOptionalParameter(StringParameter):
    """Parameter for optional string inputs"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = False


# Map of python type annotations to parameter types.
TYPE_ANNOTATION_TO_IDEAS_PARAMETER_TYPE = {
    # pathlib.Path is a hacky way to indicate an input file for the tool runner using just the standard lib
    # this not publicly documented but still included for internal support
    "pathlib.Path": PathParameter,
    "Optional[pathlib.Path]": PathOptionalParameter,
    "pathlib.Path | None": PathOptionalParameter,
    "List[pathlib.Path]": PathMultipleParameter,
    "Optional[List[pathlib.Path]]": PathMultipleOptionalParameter,
    "List[pathlib.Path] | None": PathMultipleOptionalParameter,
    # IdeasFile is the recommended approach for indicating input files
    "IdeasFile": PathParameter,
    "Optional[IdeasFile]": PathOptionalParameter,
    "IdeasFile | None": PathOptionalParameter,
    "List[IdeasFile]": PathMultipleParameter,
    "Optional[List[IdeasFile]]": PathMultipleOptionalParameter,
    "List[IdeasFile] | None": PathMultipleOptionalParameter,
    # Python primitive types
    "int": IntParameter,
    "Optional[int]": IntOptionalParameter,
    "int | None": IntOptionalParameter,
    "float": FloatParameter,
    "Optional[float]": FloatOptionalParameter,
    "float | None": FloatOptionalParameter,
    "bool": BoolParameter,
    "Optional[bool]": BoolOptionalParameter,
    "bool | None": BoolOptionalParameter,
    "str": StringParameter,
    "Optional[str]": StringOptionalParameter,
    "str | None": StringOptionalParameter,
}


def create_parameter(key: str, type_annotation: str, default: typing.Any):
    """
    Factory function to create a parameter from a function signature.
    This method tries to map the type annotation in the function signautre
    to a compatible IDEAS parameter type.
    If not compatible IDEAS parameter type exists, the function defaults
    to mapping to a `StringParameter` type.
    """
    param_class = TYPE_ANNOTATION_TO_IDEAS_PARAMETER_TYPE.get(
        type_annotation, StringParameter
    )

    return param_class(key=key, type_annotation=type_annotation, default=default)
