from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ideas-python")
except PackageNotFoundError:
    # package is not installed
    pass
