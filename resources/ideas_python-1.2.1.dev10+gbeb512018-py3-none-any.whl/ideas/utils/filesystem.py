import pathlib

DEFAULT_IGNORES = [
    # Only ignore top-level outputs directory
    "/outputs/",
    # Don't include IDEAS Python-related files/folders
    ".ideas/",
    "*.cbundle",
    ".ideasignore",
    # Standard python ignores—this is probably handled in most .gitignore files, but
    # it would be frustrating for users if they didn't have that tooling in place
    # and got these files
    "__pycache__/",
    "*.py[cod]",
    "*.egg-info/",
    ".DS_Store",
    "venv/",
    ".venv/",
    # Git files/folders which may be tracked but not relevant for a code bundle
    ".git/",
    ".github/",
    ".gitignore",
]


def read_ignore_patterns(
    files: list[pathlib.Path],
    extra: list[str],
    default_excludes: bool = True,
) -> list[str]:
    """
    Given a list of files and extra patterns, will return a list of patterns meant for use with the
    pathspec module.

    See https://git-scm.com/docs/gitignore for ignore syntax.

    :param files: A list of file paths containing patterns to ignore (e.g., .gitignore files).
    :param extra: Additional patterns to define on top of the ones in the supplied files.
    :param default_excludes: Control whether or not the default ignore patterns defined by IDEAS
        Python are included.
    """
    patterns = []

    # Read patterns from all passed files
    for file in files:
        with file.open() as f:
            # We can safely pass extra blank lines here, or comment lines, as pathspec handles this
            # for us.
            patterns.extend(f.readlines())

    if default_excludes:
        # Add in some static helpful ignores
        patterns.extend(DEFAULT_IGNORES)

    # Add in additional defined patterns
    patterns.extend(extra)

    return patterns
